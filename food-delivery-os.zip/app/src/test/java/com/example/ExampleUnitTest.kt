package com.example

import com.example.model.DiskAlgorithm
import com.example.model.DiskScheduler
import com.example.model.MemoryPagingEngine
import com.example.model.OrderScheduler
import com.example.model.PagingSpec
import com.example.model.ScanDirection
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
  @Test
  fun testRoundRobinScheduling() {
    val result = OrderScheduler.runRoundRobin(OrderScheduler.DEFAULT_PROCESSES, 2)
    assertEquals(5, result.metrics.size)
    assertEquals(20, result.totalTime)
    
    // Verify completion times
    val p1 = result.metrics.find { it.id == "P1" }
    val p2 = result.metrics.find { it.id == "P2" }
    val p3 = result.metrics.find { it.id == "P3" }
    val p4 = result.metrics.find { it.id == "P4" }
    val p5 = result.metrics.find { it.id == "P5" }

    assertNotNull(p1)
    assertNotNull(p2)
    assertNotNull(p3)
    assertNotNull(p4)
    assertNotNull(p5)

    assertEquals(8, p1?.completionTime)
    assertEquals(11, p2?.completionTime)
    assertEquals(18, p3?.completionTime)
    assertEquals(10, p4?.completionTime)
    assertEquals(20, p5?.completionTime)
  }

  @Test
  fun testMemoryPagingCalculations() {
    val spec = PagingSpec()
    assertEquals(8192L, spec.totalPages)
    assertEquals(1048576L, spec.totalFrames)

    val fifo = MemoryPagingEngine.simulateFIFO()
    val lru = MemoryPagingEngine.simulateLRU()

    assertTrue(fifo.totalFaults > 0)
    assertTrue(lru.totalFaults > 0)
    assertTrue(lru.totalFaults <= fifo.totalFaults)

    // Address translation test
    val trans = MemoryPagingEngine.translateAddress(2, 512, MemoryPagingEngine.DEFAULT_PAGE_TABLE)
    assertTrue(trans.isValid)
    assertEquals(104, trans.frameNumber)
    assertEquals(426496L, trans.physicalAddress)
  }

  @Test
  fun testDiskSchedulingAlgorithms() {
    val head = 40
    val queue = listOf(55, 18, 90, 66, 32, 75)

    val fcfs = DiskScheduler.simulate(DiskAlgorithm.FCFS, head, queue, 0, 100)
    assertEquals(225, fcfs.totalSeekDistance)

    val sstf = DiskScheduler.simulate(DiskAlgorithm.SSTF, head, queue, 0, 100)
    assertEquals(94, sstf.totalSeekDistance)

    val scan = DiskScheduler.simulate(DiskAlgorithm.SCAN, head, queue, 0, 100, ScanDirection.TOWARDS_HIGH)
    assertEquals(142, scan.totalSeekDistance)

    val look = DiskScheduler.simulate(DiskAlgorithm.LOOK, head, queue, 0, 100, ScanDirection.TOWARDS_HIGH)
    assertEquals(122, look.totalSeekDistance)
  }
}

