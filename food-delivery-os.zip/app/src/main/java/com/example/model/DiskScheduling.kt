package com.example.model

import kotlin.math.abs

enum class DiskAlgorithm(val displayName: String, val description: String) {
    FCFS("FCFS", "First-Come First-Served: Serves delivery stops in exact arrival order."),
    SSTF("SSTF", "Shortest Seek Time First: Serves nearest delivery destination next to minimize travel."),
    SCAN("SCAN", "Elevator Algorithm: Sweeps delivery vehicle in one direction to end, then reverses."),
    LOOK("LOOK", "Optimized SCAN: Sweeps in one direction up to last request, then reverses without hitting disk boundaries.")
}

enum class ScanDirection(val displayName: String) {
    TOWARDS_HIGH("Towards Cylinder 100 (High)"),
    TOWARDS_LOW("Towards Cylinder 0 (Low)")
}

data class DiskHop(
    val stepIndex: Int,
    val fromCylinder: Int,
    val toCylinder: Int,
    val seekDistance: Int,
    val isBoundary: Boolean = false,
    val description: String
)

data class DiskSimulationResult(
    val algorithm: DiskAlgorithm,
    val initialHead: Int,
    val maxCylinder: Int,
    val minCylinder: Int,
    val requestQueue: List<Int>,
    val fullSequence: List<Int>,
    val hops: List<DiskHop>,
    val totalSeekDistance: Int,
    val averageSeekDistance: Double
)

object DiskScheduler {

    const val DEFAULT_INITIAL_HEAD = 40
    const val DEFAULT_MAX_CYLINDER = 100
    const val DEFAULT_MIN_CYLINDER = 0
    val DEFAULT_QUEUE = listOf(55, 18, 90, 66, 32, 75)

    fun simulate(
        algorithm: DiskAlgorithm,
        initialHead: Int = DEFAULT_INITIAL_HEAD,
        queue: List<Int> = DEFAULT_QUEUE,
        minCylinder: Int = DEFAULT_MIN_CYLINDER,
        maxCylinder: Int = DEFAULT_MAX_CYLINDER,
        direction: ScanDirection = ScanDirection.TOWARDS_HIGH
    ): DiskSimulationResult {
        if (queue.isEmpty()) {
            return DiskSimulationResult(
                algorithm, initialHead, maxCylinder, minCylinder, queue,
                listOf(initialHead), emptyList(), 0, 0.0
            )
        }

        val sequence = mutableListOf<Int>()
        sequence.add(initialHead)

        when (algorithm) {
            DiskAlgorithm.FCFS -> {
                sequence.addAll(queue)
            }
            DiskAlgorithm.SSTF -> {
                val remaining = queue.toMutableList()
                var current = initialHead
                while (remaining.isNotEmpty()) {
                    val nearest = remaining.minByOrNull { abs(it - current) }!!
                    sequence.add(nearest)
                    remaining.remove(nearest)
                    current = nearest
                }
            }
            DiskAlgorithm.SCAN -> {
                val left = queue.filter { it < initialHead }.sorted()
                val right = queue.filter { it >= initialHead }.sorted()

                if (direction == ScanDirection.TOWARDS_HIGH) {
                    sequence.addAll(right)
                    // If there are requests to the left, must go all the way to maxCylinder boundary
                    if (left.isNotEmpty()) {
                        sequence.add(maxCylinder)
                        sequence.addAll(left.reversed())
                    }
                } else {
                    sequence.addAll(left.reversed())
                    if (right.isNotEmpty()) {
                        sequence.add(minCylinder)
                        sequence.addAll(right)
                    }
                }
            }
            DiskAlgorithm.LOOK -> {
                val left = queue.filter { it < initialHead }.sorted()
                val right = queue.filter { it >= initialHead }.sorted()

                if (direction == ScanDirection.TOWARDS_HIGH) {
                    sequence.addAll(right)
                    sequence.addAll(left.reversed())
                } else {
                    sequence.addAll(left.reversed())
                    sequence.addAll(right)
                }
            }
        }

        val hops = mutableListOf<DiskHop>()
        var totalSeek = 0
        for (i in 0 until sequence.size - 1) {
            val from = sequence[i]
            val to = sequence[i + 1]
            val dist = abs(to - from)
            totalSeek += dist
            val isBoundary = (to == maxCylinder || to == minCylinder) && !queue.contains(to)
            val desc = if (isBoundary) {
                "Delivery vehicle swept to disk boundary $to (Seek: +$dist cyl)"
            } else {
                "Delivered order at Zone/Cylinder $to (Seek: +$dist cyl)"
            }
            hops.add(DiskHop(i + 1, from, to, dist, isBoundary, desc))
        }

        val avgSeek = if (queue.isNotEmpty()) totalSeek.toDouble() / queue.size else 0.0

        return DiskSimulationResult(
            algorithm = algorithm,
            initialHead = initialHead,
            maxCylinder = maxCylinder,
            minCylinder = minCylinder,
            requestQueue = queue,
            fullSequence = sequence,
            hops = hops,
            totalSeekDistance = totalSeek,
            averageSeekDistance = avgSeek
        )
    }
}
