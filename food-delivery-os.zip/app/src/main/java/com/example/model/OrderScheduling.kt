package com.example.model

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.ProcessP1
import com.example.ui.theme.ProcessP2
import com.example.ui.theme.ProcessP3
import com.example.ui.theme.ProcessP4
import com.example.ui.theme.ProcessP5

data class FoodOrderProcess(
    val id: String,
    val name: String,
    val arrivalTime: Int,
    val burstTime: Int,
    val color: Color
)

data class ProcessMetrics(
    val id: String,
    val name: String,
    val arrivalTime: Int,
    val burstTime: Int,
    val completionTime: Int,
    val turnaroundTime: Int,
    val waitingTime: Int,
    val responseTime: Int,
    val color: Color
)

data class GanttBlock(
    val processId: String,
    val processName: String,
    val startTime: Int,
    val endTime: Int,
    val color: Color
)

data class SimulationStep(
    val time: Int,
    val runningProcessId: String?,
    val readyQueue: List<String>,
    val completedProcessIds: List<String>,
    val ganttBlocksSoFar: List<GanttBlock>,
    val description: String
)

data class RoundRobinResult(
    val quantum: Int,
    val processes: List<FoodOrderProcess>,
    val ganttBlocks: List<GanttBlock>,
    val metrics: List<ProcessMetrics>,
    val averageTurnaroundTime: Double,
    val averageWaitingTime: Double,
    val totalTime: Int,
    val steps: List<SimulationStep>
)

object OrderScheduler {

    val DEFAULT_PROCESSES = listOf(
        FoodOrderProcess("P1", "Order #101 (Pizza Margherita)", 0, 4, ProcessP1),
        FoodOrderProcess("P2", "Order #102 (Sushi Platter)", 1, 3, ProcessP2),
        FoodOrderProcess("P3", "Order #103 (Burger & Fries)", 2, 5, ProcessP3),
        FoodOrderProcess("P4", "Order #104 (Pad Thai)", 3, 2, ProcessP4),
        FoodOrderProcess("P5", "Order #105 (Burrito Bowl)", 5, 6, ProcessP5)
    )

    fun runRoundRobin(
        processes: List<FoodOrderProcess> = DEFAULT_PROCESSES,
        quantum: Int = 2
    ): RoundRobinResult {
        if (processes.isEmpty()) {
            return RoundRobinResult(quantum, emptyList(), emptyList(), emptyList(), 0.0, 0.0, 0, emptyList())
        }

        val procMap = processes.associateBy { it.id }
        val remainingTime = processes.associate { it.id to it.burstTime }.toMutableMap()
        val firstResponse = mutableMapOf<String, Int>()
        val completionTimes = mutableMapOf<String, Int>()

        val readyQueue = ArrayDeque<String>()
        val arrivalSorted = processes.sortedBy { it.arrivalTime }
        val arrivedSet = mutableSetOf<String>()

        var currentTime = 0
        val ganttBlocks = mutableListOf<GanttBlock>()
        val steps = mutableListOf<SimulationStep>()

        // Check who arrived at t=0
        for (p in arrivalSorted) {
            if (p.arrivalTime <= currentTime && !arrivedSet.contains(p.id)) {
                readyQueue.addLast(p.id)
                arrivedSet.add(p.id)
            }
        }

        val completed = mutableListOf<String>()

        steps.add(
            SimulationStep(
                time = 0,
                runningProcessId = null,
                readyQueue = readyQueue.toList(),
                completedProcessIds = emptyList(),
                ganttBlocksSoFar = emptyList(),
                description = "Simulation initialized. Chef ready queue: ${readyQueue.joinToString()}"
            )
        )

        while (completed.size < processes.size) {
            if (readyQueue.isEmpty()) {
                // CPU is idle until next arrival
                val nextArrival = arrivalSorted.firstOrNull { !arrivedSet.contains(it.id) }
                if (nextArrival != null) {
                    val idleStart = currentTime
                    currentTime = nextArrival.arrivalTime
                    ganttBlocks.add(
                        GanttBlock("IDLE", "Idle Kitchen", idleStart, currentTime, Color(0xFF475569))
                    )
                    for (p in arrivalSorted) {
                        if (p.arrivalTime <= currentTime && !arrivedSet.contains(p.id)) {
                            readyQueue.addLast(p.id)
                            arrivedSet.add(p.id)
                        }
                    }
                    steps.add(
                        SimulationStep(
                            time = currentTime,
                            runningProcessId = null,
                            readyQueue = readyQueue.toList(),
                            completedProcessIds = completed.toList(),
                            ganttBlocksSoFar = ganttBlocks.toList(),
                            description = "Kitchen idle until t=$currentTime. ${nextArrival.id} arrives."
                        )
                    )
                    continue
                } else {
                    break
                }
            }

            val currentProcId = readyQueue.removeFirst()
            val proc = procMap[currentProcId]!!
            if (!firstResponse.containsKey(currentProcId)) {
                firstResponse[currentProcId] = currentTime
            }

            val rem = remainingTime[currentProcId] ?: 0
            val execTime = minOf(quantum, rem)
            val startTime = currentTime
            currentTime += execTime
            remainingTime[currentProcId] = rem - execTime

            val block = GanttBlock(
                processId = currentProcId,
                processName = proc.name,
                startTime = startTime,
                endTime = currentTime,
                color = proc.color
            )
            ganttBlocks.add(block)

            // Add newly arrived processes during this time interval
            for (p in arrivalSorted) {
                if (p.arrivalTime <= currentTime && !arrivedSet.contains(p.id)) {
                    readyQueue.addLast(p.id)
                    arrivedSet.add(p.id)
                }
            }

            // Check if current process finished or goes back to queue
            if (remainingTime[currentProcId] == 0) {
                completionTimes[currentProcId] = currentTime
                completed.add(currentProcId)
                steps.add(
                    SimulationStep(
                        time = currentTime,
                        runningProcessId = currentProcId,
                        readyQueue = readyQueue.toList(),
                        completedProcessIds = completed.toList(),
                        ganttBlocksSoFar = ganttBlocks.toList(),
                        description = "t=$startTime->$currentTime: ${proc.id} executed for ${execTime}u and COMPLETED."
                    )
                )
            } else {
                readyQueue.addLast(currentProcId)
                steps.add(
                    SimulationStep(
                        time = currentTime,
                        runningProcessId = currentProcId,
                        readyQueue = readyQueue.toList(),
                        completedProcessIds = completed.toList(),
                        ganttBlocksSoFar = ganttBlocks.toList(),
                        description = "t=$startTime->$currentTime: ${proc.id} executed for ${execTime}u. Rem: ${remainingTime[currentProcId]}u. Preempted to queue."
                    )
                )
            }
        }

        val metricsList = processes.map { p ->
            val ct = completionTimes[p.id] ?: 0
            val tat = ct - p.arrivalTime
            val wt = tat - p.burstTime
            val rt = (firstResponse[p.id] ?: p.arrivalTime) - p.arrivalTime
            ProcessMetrics(
                id = p.id,
                name = p.name,
                arrivalTime = p.arrivalTime,
                burstTime = p.burstTime,
                completionTime = ct,
                turnaroundTime = tat,
                waitingTime = wt,
                responseTime = rt,
                color = p.color
            )
        }

        val avgTat = if (metricsList.isNotEmpty()) metricsList.map { it.turnaroundTime }.average() else 0.0
        val avgWt = if (metricsList.isNotEmpty()) metricsList.map { it.waitingTime }.average() else 0.0

        return RoundRobinResult(
            quantum = quantum,
            processes = processes,
            ganttBlocks = ganttBlocks,
            metrics = metricsList,
            averageTurnaroundTime = avgTat,
            averageWaitingTime = avgWt,
            totalTime = currentTime,
            steps = steps
        )
    }
}
