package com.example.model

data class PagingSpec(
    val ramSizeBytes: Long = 4L * 1024 * 1024 * 1024, // 4 GB
    val pageSizeBytes: Long = 4L * 1024,              // 4 KB
    val logicalSizeBytes: Long = 32L * 1024 * 1024,   // 32 MB
    val allocatedFramesCount: Int = 3
) {
    val totalPages: Long = logicalSizeBytes / pageSizeBytes      // 8,192
    val totalFrames: Long = ramSizeBytes / pageSizeBytes        // 1,048,576

    val offsetBits: Int = 12       // log2(4096)
    val pageNumberBits: Int = 13   // log2(8192)
    val frameNumberBits: Int = 20  // log2(1048576)
    val logicalAddressBits: Int = pageNumberBits + offsetBits  // 25 bits
    val physicalAddressBits: Int = frameNumberBits + offsetBits // 32 bits
}

data class PageTableEntry(
    val pageNumber: Int,
    val moduleName: String,
    val frameNumber: Int?,
    val isValid: Boolean,
    val isDirty: Boolean,
    val description: String
)

data class PageFaultStep(
    val stepIndex: Int,
    val pageReferenced: Int,
    val framesState: List<Int?>, // size = allocatedFrames
    val isHit: Boolean,
    val evictedPage: Int?,
    val explanation: String
)

data class PageReplacementResult(
    val algorithmName: String,
    val referenceString: List<Int>,
    val frameCount: Int,
    val steps: List<PageFaultStep>,
    val totalFaults: Int,
    val totalHits: Int,
    val faultRate: Double,
    val hitRate: Double
)

object MemoryPagingEngine {

    val DEFAULT_PAGE_TABLE = listOf(
        PageTableEntry(0, "App Kernel & Router", 104, isValid = true, isDirty = false, "Core food app runtime"),
        PageTableEntry(1, "Menu Catalog Cache", 512, isValid = true, isDirty = false, "Restaurants & food items"),
        PageTableEntry(2, "Live Cart & Discounts", 890, isValid = true, isDirty = true, "Active customer cart state"),
        PageTableEntry(3, "Courier GPS Tracker", null, isValid = false, isDirty = false, "Swapped to disk storage"),
        PageTableEntry(4, "Stripe Payment Gateway", null, isValid = false, isDirty = false, "Swapped to disk storage"),
        PageTableEntry(5, "Kitchen Live Stream", null, isValid = false, isDirty = false, "Swapped to disk storage"),
        PageTableEntry(6, "Reviews & Ratings DB", null, isValid = false, isDirty = false, "Swapped to disk storage"),
        PageTableEntry(7, "User Profile & Orders", null, isValid = false, isDirty = false, "Swapped to disk storage")
    )

    val DEFAULT_REFERENCE_STRING = listOf(7, 0, 1, 2, 0, 3, 0, 4, 2, 3, 0, 3, 2)

    fun simulateFIFO(
        referenceString: List<Int> = DEFAULT_REFERENCE_STRING,
        frameCount: Int = 3
    ): PageReplacementResult {
        val frames = MutableList<Int?>(frameCount) { null }
        val fifoQueue = ArrayDeque<Int>()
        val steps = mutableListOf<PageFaultStep>()
        var faults = 0
        var hits = 0

        referenceString.forEachIndexed { idx, page ->
            val isHit = frames.contains(page)
            var evicted: Int? = null
            var explanation: String

            if (isHit) {
                hits++
                explanation = "Page $page is already loaded in RAM. Page HIT."
            } else {
                faults++
                val emptyIndex = frames.indexOf(null)
                if (emptyIndex != -1) {
                    frames[emptyIndex] = page
                    fifoQueue.addLast(page)
                    explanation = "Frame slot available. Loaded Page $page. Page FAULT."
                } else {
                    evicted = fifoQueue.removeFirst()
                    val replaceIndex = frames.indexOf(evicted)
                    frames[replaceIndex] = page
                    fifoQueue.addLast(page)
                    explanation = "RAM Full. Evicted oldest Page $evicted, inserted Page $page. Page FAULT."
                }
            }

            steps.add(
                PageFaultStep(
                    stepIndex = idx + 1,
                    pageReferenced = page,
                    framesState = frames.toList(),
                    isHit = isHit,
                    evictedPage = evicted,
                    explanation = explanation
                )
            )
        }

        val total = referenceString.size
        val faultRate = if (total > 0) (faults.toDouble() / total) * 100.0 else 0.0
        val hitRate = if (total > 0) (hits.toDouble() / total) * 100.0 else 0.0

        return PageReplacementResult(
            algorithmName = "FIFO (First-In, First-Out)",
            referenceString = referenceString,
            frameCount = frameCount,
            steps = steps,
            totalFaults = faults,
            totalHits = hits,
            faultRate = faultRate,
            hitRate = hitRate
        )
    }

    fun simulateLRU(
        referenceString: List<Int> = DEFAULT_REFERENCE_STRING,
        frameCount: Int = 3
    ): PageReplacementResult {
        val frames = MutableList<Int?>(frameCount) { null }
        val lruOrder = mutableListOf<Int>() // most recent at end
        val steps = mutableListOf<PageFaultStep>()
        var faults = 0
        var hits = 0

        referenceString.forEachIndexed { idx, page ->
            val isHit = frames.contains(page)
            var evicted: Int? = null
            var explanation: String

            if (isHit) {
                hits++
                lruOrder.remove(page)
                lruOrder.add(page)
                explanation = "Page $page is already in RAM. Updated recency. Page HIT."
            } else {
                faults++
                val emptyIndex = frames.indexOf(null)
                if (emptyIndex != -1) {
                    frames[emptyIndex] = page
                    lruOrder.add(page)
                    explanation = "Empty frame found. Loaded Page $page. Page FAULT."
                } else {
                    evicted = lruOrder.removeAt(0) // least recently used is index 0
                    val replaceIndex = frames.indexOf(evicted)
                    frames[replaceIndex] = page
                    lruOrder.add(page)
                    explanation = "RAM full. Evicted least recently accessed Page $evicted, loaded Page $page. Page FAULT."
                }
            }

            steps.add(
                PageFaultStep(
                    stepIndex = idx + 1,
                    pageReferenced = page,
                    framesState = frames.toList(),
                    isHit = isHit,
                    evictedPage = evicted,
                    explanation = explanation
                )
            )
        }

        val total = referenceString.size
        val faultRate = if (total > 0) (faults.toDouble() / total) * 100.0 else 0.0
        val hitRate = if (total > 0) (hits.toDouble() / total) * 100.0 else 0.0

        return PageReplacementResult(
            algorithmName = "LRU (Least Recently Used)",
            referenceString = referenceString,
            frameCount = frameCount,
            steps = steps,
            totalFaults = faults,
            totalHits = hits,
            faultRate = faultRate,
            hitRate = hitRate
        )
    }

    fun translateAddress(
        pageNumber: Int,
        offset: Int,
        pageTable: List<PageTableEntry>
    ): AddressTranslationResult {
        val entry = pageTable.firstOrNull { it.pageNumber == pageNumber }
        if (entry == null || !entry.isValid || entry.frameNumber == null) {
            return AddressTranslationResult(
                isValid = false,
                pageNumber = pageNumber,
                offset = offset,
                frameNumber = null,
                physicalAddress = null,
                errorMessage = "Page Fault! Page $pageNumber is not mapped to physical RAM (Invalid Bit)."
            )
        }
        val physicalAddress = (entry.frameNumber.toLong() * 4096L) + offset.toLong()
        return AddressTranslationResult(
            isValid = true,
            pageNumber = pageNumber,
            offset = offset,
            frameNumber = entry.frameNumber,
            physicalAddress = physicalAddress,
            errorMessage = null
        )
    }
}

data class AddressTranslationResult(
    val isValid: Boolean,
    val pageNumber: Int,
    val offset: Int,
    val frameNumber: Int?,
    val physicalAddress: Long?,
    val errorMessage: String?
)
