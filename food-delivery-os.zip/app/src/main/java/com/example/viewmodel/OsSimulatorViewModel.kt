package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.AddressTranslationResult
import com.example.model.DiskAlgorithm
import com.example.model.DiskScheduler
import com.example.model.DiskSimulationResult
import com.example.model.FoodOrderProcess
import com.example.model.MemoryPagingEngine
import com.example.model.OrderScheduler
import com.example.model.PageReplacementResult
import com.example.model.PageTableEntry
import com.example.model.PagingSpec
import com.example.model.RoundRobinResult
import com.example.model.ScanDirection
import com.example.network.GeminiApiClient
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class DashboardTab(val title: String, val subtitle: String) {
    OVERVIEW("Overview", "OS Food Delivery Hub"),
    ROUND_ROBIN("CPU Scheduling", "Round Robin (RR)"),
    MEMORY_PAGING("Memory Paging", "4GB RAM & Faults"),
    DISK_SCHEDULING("Route Optimization", "Disk Head Algorithms"),
    AI_TUTOR("AI OS Tutor", "Gemini Explanations")
}

data class ChatMessage(
    val id: String,
    val sender: String, // "User" or "Gemini Tutor"
    val text: String,
    val isUser: Boolean,
    val timestamp: Long = System.currentTimeMillis()
)

data class OsSimulatorUiState(
    val currentTab: DashboardTab = DashboardTab.OVERVIEW,
    // Round Robin
    val rrQuantum: Int = 2,
    val rrProcesses: List<FoodOrderProcess> = OrderScheduler.DEFAULT_PROCESSES,
    val rrResult: RoundRobinResult = OrderScheduler.runRoundRobin(OrderScheduler.DEFAULT_PROCESSES, 2),
    val rrStepIndex: Int = 0,
    val isRrPlaying: Boolean = false,
    val rrSpeedMs: Long = 900L,

    // Memory Paging
    val pagingSpec: PagingSpec = PagingSpec(),
    val pageTable: List<PageTableEntry> = MemoryPagingEngine.DEFAULT_PAGE_TABLE,
    val referenceString: List<Int> = MemoryPagingEngine.DEFAULT_REFERENCE_STRING,
    val fifoResult: PageReplacementResult = MemoryPagingEngine.simulateFIFO(),
    val lruResult: PageReplacementResult = MemoryPagingEngine.simulateLRU(),
    val pagingActiveAlgo: String = "FIFO", // "FIFO", "LRU", or "COMPARE"
    val pagingStepIndex: Int = 0,
    val inputPageNum: String = "2",
    val inputOffset: String = "512",
    val translationResult: AddressTranslationResult? = MemoryPagingEngine.translateAddress(2, 512, MemoryPagingEngine.DEFAULT_PAGE_TABLE),

    // Disk Scheduling
    val diskInitialHead: Int = DiskScheduler.DEFAULT_INITIAL_HEAD,
    val diskQueue: List<Int> = DiskScheduler.DEFAULT_QUEUE,
    val diskDirection: ScanDirection = ScanDirection.TOWARDS_HIGH,
    val selectedDiskAlgo: DiskAlgorithm = DiskAlgorithm.FCFS,
    val fcfsResult: DiskSimulationResult = DiskScheduler.simulate(DiskAlgorithm.FCFS),
    val sstfResult: DiskSimulationResult = DiskScheduler.simulate(DiskAlgorithm.SSTF),
    val scanResult: DiskSimulationResult = DiskScheduler.simulate(DiskAlgorithm.SCAN),
    val lookResult: DiskSimulationResult = DiskScheduler.simulate(DiskAlgorithm.LOOK),
    val diskStepIndex: Int = 0,
    val isDiskPlaying: Boolean = false,

    // AI Tutor
    val chatMessages: List<ChatMessage> = listOf(
        ChatMessage(
            id = "welcome",
            sender = "Gemini Tutor",
            text = "👋 Welcome to the **Online Food Delivery OS Simulator**! I'm your AI Operating Systems Tutor.\n\nI can explain any step of **Round Robin Scheduling**, **Memory Paging / FIFO & LRU**, or **Disk Route Optimization**.\n\nTap a quick question below or ask me anything!",
            isUser = false
        )
    ),
    val isAiThinking: Boolean = false,
    val isApiKeyConfigured: Boolean = GeminiApiClient.isApiKeyConfigured()
)

class OsSimulatorViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(OsSimulatorUiState())
    val uiState: StateFlow<OsSimulatorUiState> = _uiState.asStateFlow()

    private var rrPlaybackJob: Job? = null
    private var diskPlaybackJob: Job? = null

    init {
        recalculateDiskSimulations()
    }

    fun selectTab(tab: DashboardTab) {
        _uiState.update { it.copy(currentTab = tab) }
    }

    // --- Round Robin Controls ---
    fun setQuantum(newQuantum: Int) {
        val clamped = newQuantum.coerceIn(1, 10)
        val result = OrderScheduler.runRoundRobin(_uiState.value.rrProcesses, clamped)
        _uiState.update {
            it.copy(
                rrQuantum = clamped,
                rrResult = result,
                rrStepIndex = 0,
                isRrPlaying = false
            )
        }
        rrPlaybackJob?.cancel()
    }

    fun setRrStep(stepIndex: Int) {
        val maxStep = _uiState.value.rrResult.steps.size - 1
        _uiState.update { it.copy(rrStepIndex = stepIndex.coerceIn(0, maxOf(0, maxStep))) }
    }

    fun toggleRrPlayback() {
        if (_uiState.value.isRrPlaying) {
            pauseRrPlayback()
        } else {
            startRrPlayback()
        }
    }

    private fun startRrPlayback() {
        rrPlaybackJob?.cancel()
        _uiState.update { it.copy(isRrPlaying = true) }
        rrPlaybackJob = viewModelScope.launch {
            val stepsCount = _uiState.value.rrResult.steps.size
            if (_uiState.value.rrStepIndex >= stepsCount - 1) {
                _uiState.update { it.copy(rrStepIndex = 0) }
            }
            while (_uiState.value.rrStepIndex < stepsCount - 1 && _uiState.value.isRrPlaying) {
                delay(_uiState.value.rrSpeedMs)
                _uiState.update { it.copy(rrStepIndex = it.rrStepIndex + 1) }
            }
            _uiState.update { it.copy(isRrPlaying = false) }
        }
    }

    fun pauseRrPlayback() {
        rrPlaybackJob?.cancel()
        _uiState.update { it.copy(isRrPlaying = false) }
    }

    fun resetRrSimulation() {
        pauseRrPlayback()
        val result = OrderScheduler.runRoundRobin(OrderScheduler.DEFAULT_PROCESSES, _uiState.value.rrQuantum)
        _uiState.update {
            it.copy(
                rrProcesses = OrderScheduler.DEFAULT_PROCESSES,
                rrResult = result,
                rrStepIndex = 0,
                isRrPlaying = false
            )
        }
    }

    // --- Memory Paging Controls ---
    fun setPagingActiveAlgo(algo: String) {
        _uiState.update { it.copy(pagingActiveAlgo = algo, pagingStepIndex = 0) }
    }

    fun setPagingStep(step: Int) {
        val maxSteps = _uiState.value.referenceString.size
        _uiState.update { it.copy(pagingStepIndex = step.coerceIn(0, maxSteps)) }
    }

    fun updateReferenceString(newRefString: List<Int>) {
        val fifo = MemoryPagingEngine.simulateFIFO(newRefString, _uiState.value.pagingSpec.allocatedFramesCount)
        val lru = MemoryPagingEngine.simulateLRU(newRefString, _uiState.value.pagingSpec.allocatedFramesCount)
        _uiState.update {
            it.copy(
                referenceString = newRefString,
                fifoResult = fifo,
                lruResult = lru,
                pagingStepIndex = 0
            )
        }
    }

    fun updateTranslationInputs(pageStr: String, offsetStr: String) {
        val pageNum = pageStr.toIntOrNull() ?: 0
        val offset = offsetStr.toIntOrNull() ?: 0
        val res = MemoryPagingEngine.translateAddress(pageNum, offset, _uiState.value.pageTable)
        _uiState.update {
            it.copy(
                inputPageNum = pageStr,
                inputOffset = offsetStr,
                translationResult = res
            )
        }
    }

    // --- Disk Scheduling Controls ---
    fun selectDiskAlgorithm(algo: DiskAlgorithm) {
        _uiState.update { it.copy(selectedDiskAlgo = algo, diskStepIndex = 0, isDiskPlaying = false) }
        diskPlaybackJob?.cancel()
    }

    fun setDiskInitialHead(head: Int) {
        val clamped = head.coerceIn(0, 100)
        _uiState.update { it.copy(diskInitialHead = clamped, diskStepIndex = 0) }
        recalculateDiskSimulations()
    }

    fun setScanDirection(direction: ScanDirection) {
        _uiState.update { it.copy(diskDirection = direction, diskStepIndex = 0) }
        recalculateDiskSimulations()
    }

    fun setDiskQueue(newQueue: List<Int>) {
        _uiState.update { it.copy(diskQueue = newQueue, diskStepIndex = 0) }
        recalculateDiskSimulations()
    }

    fun setDiskStep(step: Int) {
        val currentResult = getCurrentDiskResult()
        val maxStep = currentResult.fullSequence.size - 1
        _uiState.update { it.copy(diskStepIndex = step.coerceIn(0, maxOf(0, maxStep))) }
    }

    fun toggleDiskPlayback() {
        if (_uiState.value.isDiskPlaying) {
            pauseDiskPlayback()
        } else {
            startDiskPlayback()
        }
    }

    private fun startDiskPlayback() {
        diskPlaybackJob?.cancel()
        _uiState.update { it.copy(isDiskPlaying = true) }
        diskPlaybackJob = viewModelScope.launch {
            val maxStep = getCurrentDiskResult().fullSequence.size - 1
            if (_uiState.value.diskStepIndex >= maxStep) {
                _uiState.update { it.copy(diskStepIndex = 0) }
            }
            while (_uiState.value.diskStepIndex < maxStep && _uiState.value.isDiskPlaying) {
                delay(700L)
                _uiState.update { it.copy(diskStepIndex = it.diskStepIndex + 1) }
            }
            _uiState.update { it.copy(isDiskPlaying = false) }
        }
    }

    fun pauseDiskPlayback() {
        diskPlaybackJob?.cancel()
        _uiState.update { it.copy(isDiskPlaying = false) }
    }

    private fun recalculateDiskSimulations() {
        val head = _uiState.value.diskInitialHead
        val queue = _uiState.value.diskQueue
        val dir = _uiState.value.diskDirection

        val fcfs = DiskScheduler.simulate(DiskAlgorithm.FCFS, head, queue, 0, 100, dir)
        val sstf = DiskScheduler.simulate(DiskAlgorithm.SSTF, head, queue, 0, 100, dir)
        val scan = DiskScheduler.simulate(DiskAlgorithm.SCAN, head, queue, 0, 100, dir)
        val look = DiskScheduler.simulate(DiskAlgorithm.LOOK, head, queue, 0, 100, dir)

        _uiState.update {
            it.copy(
                fcfsResult = fcfs,
                sstfResult = sstf,
                scanResult = scan,
                lookResult = look
            )
        }
    }

    fun getCurrentDiskResult(): DiskSimulationResult {
        return when (_uiState.value.selectedDiskAlgo) {
            DiskAlgorithm.FCFS -> _uiState.value.fcfsResult
            DiskAlgorithm.SSTF -> _uiState.value.sstfResult
            DiskAlgorithm.SCAN -> _uiState.value.scanResult
            DiskAlgorithm.LOOK -> _uiState.value.lookResult
        }
    }

    // --- AI Tutor Interaction ---
    fun askAiTutor(question: String) {
        if (question.isBlank() || _uiState.value.isAiThinking) return

        val userMsg = ChatMessage(
            id = System.currentTimeMillis().toString(),
            sender = "You",
            text = question,
            isUser = true
        )

        _uiState.update {
            it.copy(
                chatMessages = it.chatMessages + userMsg,
                isAiThinking = true
            )
        }

        val contextSnapshot = buildCurrentContextSnapshot()

        viewModelScope.launch {
            val responseText = GeminiApiClient.askTutor(question, contextSnapshot)
            val tutorMsg = ChatMessage(
                id = (System.currentTimeMillis() + 1).toString(),
                sender = "Gemini Tutor",
                text = responseText,
                isUser = false
            )
            _uiState.update {
                it.copy(
                    chatMessages = it.chatMessages + tutorMsg,
                    isAiThinking = false
                )
            }
        }
    }

    private fun buildCurrentContextSnapshot(): String {
        val state = _uiState.value
        val diskRes = getCurrentDiskResult()
        return """
            [CPU Round Robin]:
            - Quantum: ${state.rrQuantum}
            - Processes: ${state.rrProcesses.joinToString { "${it.id}(AT:${it.arrivalTime}, BT:${it.burstTime})" }}
            - Avg TAT: ${String.format("%.2f", state.rrResult.averageTurnaroundTime)} ms
            - Avg WT: ${String.format("%.2f", state.rrResult.averageWaitingTime)} ms
            
            [Memory Paging]:
            - RAM: 4GB, Page Size: 4KB, Logical Space: 32MB
            - Total Pages: ${state.pagingSpec.totalPages}, Total Frames: ${state.pagingSpec.totalFrames}
            - Allocated Frames: ${state.pagingSpec.allocatedFramesCount}
            - Reference String: ${state.referenceString}
            - FIFO Page Faults: ${state.fifoResult.totalFaults} (${String.format("%.1f", state.fifoResult.faultRate)}%)
            - LRU Page Faults: ${state.lruResult.totalFaults} (${String.format("%.1f", state.lruResult.faultRate)}%)
            
            [Disk Scheduling]:
            - Cylinder Range: 0-100, Start Head: ${state.diskInitialHead}
            - Queue: ${state.diskQueue}
            - Current Algo: ${diskRes.algorithm.name}
            - FCFS Total Seek: ${state.fcfsResult.totalSeekDistance} cyl
            - SSTF Total Seek: ${state.sstfResult.totalSeekDistance} cyl
            - SCAN Total Seek: ${state.scanResult.totalSeekDistance} cyl
        """.trimIndent()
    }
}
