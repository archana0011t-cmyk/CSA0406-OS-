package com.example.network

import android.util.Log
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object GeminiApiClient {

    private const val TAG = "GeminiApiClient"
    private const val MODEL = "gemini-3.5-flash"
    private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models"

    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    fun isApiKeyConfigured(): Boolean {
        return try {
            val key = BuildConfig.GEMINI_API_KEY
            key.isNotBlank() && key != "MY_GEMINI_API_KEY"
        } catch (e: Throwable) {
            false
        }
    }

    suspend fun askTutor(
        prompt: String,
        currentContext: String = ""
    ): String = withContext(Dispatchers.IO) {
        val apiKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Throwable) {
            ""
        }

        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            Log.d(TAG, "API key not set, returning intelligent local OS tutor response")
            return@withContext getOfflineExplanation(prompt, currentContext)
        }

        val systemInstruction = """
            You are an expert Professor of Computer Science and Operating Systems, tutoring university students.
            You are teaching OS concepts using an 'Online Food Delivery App' metaphor:
            1. Order Processing -> CPU Scheduling (Round Robin with Quantum)
            2. Menu/Cache Allocation -> Memory Management (Paging, Address Translation, FIFO/LRU Page Replacement)
            3. Delivery Route Optimization -> Disk Head Scheduling (FCFS, SSTF, SCAN, LOOK)
            
            Always provide crystal-clear, pedagogical step-by-step breakdowns with calculations, formulas, and real-world intuition.
            Keep formatting clean with bullet points and bold section headers.
        """.trimIndent()

        val fullPrompt = if (currentContext.isNotBlank()) {
            "CURRENT SIMULATION CONTEXT:\n$currentContext\n\nSTUDENT QUESTION:\n$prompt"
        } else {
            prompt
        }

        try {
            val rootJson = JSONObject().apply {
                val contentsArray = JSONArray().apply {
                    val messageObj = JSONObject().apply {
                        val partsArray = JSONArray().apply {
                            put(JSONObject().put("text", fullPrompt))
                        }
                        put("parts", partsArray)
                    }
                    put(messageObj)
                }
                put("contents", contentsArray)

                val sysInstructionObj = JSONObject().apply {
                    val sysParts = JSONArray().apply {
                        put(JSONObject().put("text", systemInstruction))
                    }
                    put("parts", sysParts)
                }
                put("systemInstruction", sysInstructionObj)

                val genConfig = JSONObject().apply {
                    put("temperature", 0.7)
                    put("topP", 0.95)
                    put("topK", 40)
                }
                put("generationConfig", genConfig)
            }

            val requestBody = rootJson.toString().toRequestBody("application/json".toMediaType())
            val url = "$BASE_URL/$MODEL:generateContent?key=$apiKey"

            val request = Request.Builder()
                .url(url)
                .post(requestBody)
                .build()

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""

            if (!response.isSuccessful) {
                Log.e(TAG, "Gemini API Error: ${response.code} $responseBody")
                return@withContext "AI Response Error (${response.code}). Falling back to tutor notes:\n\n" +
                        getOfflineExplanation(prompt, currentContext)
            }

            val jsonRes = JSONObject(responseBody)
            val candidates = jsonRes.optJSONArray("candidates")
            if (candidates != null && candidates.length() > 0) {
                val firstCandidate = candidates.getJSONObject(0)
                val content = firstCandidate.optJSONObject("content")
                val parts = content?.optJSONArray("parts")
                if (parts != null && parts.length() > 0) {
                    return@withContext parts.getJSONObject(0).optString("text", "No response generated.")
                }
            }

            return@withContext getOfflineExplanation(prompt, currentContext)
        } catch (e: Exception) {
            Log.e(TAG, "Failed calling Gemini API", e)
            return@withContext "Network/AI connection error (${e.localizedMessage}). Here is the algorithmic walkthrough:\n\n" +
                    getOfflineExplanation(prompt, currentContext)
        }
    }

    fun getOfflineExplanation(prompt: String, context: String): String {
        val lower = prompt.lowercase()
        return when {
            lower.contains("round robin") || lower.contains("gantt") || lower.contains("waiting") || lower.contains("tat") || lower.contains("rr") -> {
                """
                ### 🍔 Round Robin (RR) Order Scheduling Walkthrough
                
                **Core Principle**: Every food order process receives a fixed time slice (Quantum = 2 units) on the kitchen CPU in cyclical FIFO order.
                
                **Step-by-Step Execution for Quantum = 2**:
                1. **t = 0**: P1 arrives (Burst: 4). Runs for 2u (t=0..2). Remainder: 2.
                   *Arrivals*: P2 arrives at t=1, P3 arrives at t=2.
                   *Queue at t=2*: [P2, P3, P1]
                2. **t = 2**: P2 runs for 2u (t=2..4). Remainder: 1.
                   *Arrivals*: P4 arrives at t=3.
                   *Queue at t=4*: [P3, P1, P4, P2]
                3. **t = 4**: P3 runs for 2u (t=4..6). Remainder: 3.
                   *Arrivals*: P5 arrives at t=5.
                   *Queue at t=6*: [P1, P4, P2, P5, P3]
                4. **t = 6**: P1 runs for remaining 2u (t=6..8). **P1 Completes at t=8!**
                5. **t = 8**: P4 runs for 2u (t=8..10). **P4 Completes at t=10!**
                6. **t = 10**: P2 runs for remaining 1u (t=10..11). **P2 Completes at t=11!**
                7. **t = 11**: P5 runs for 2u (t=11..13). Remainder: 4. Queue: [P3, P5]
                8. **t = 13**: P3 runs for 2u (t=13..15). Remainder: 1. Queue: [P5, P3]
                9. **t = 15**: P5 runs for 2u (t=15..17). Remainder: 2. Queue: [P3, P5]
                10. **t = 17**: P3 runs for remaining 1u (t=17..18). **P3 Completes at t=18!**
                11. **t = 18**: P5 runs for remaining 2u (t=18..20). **P5 Completes at t=20!**
                
                **Summary Metrics Table**:
                * **P1**: CT = 8, TAT = 8 - 0 = 8, WT = 8 - 4 = 4
                * **P2**: CT = 11, TAT = 11 - 1 = 10, WT = 10 - 3 = 7
                * **P3**: CT = 18, TAT = 18 - 2 = 16, WT = 16 - 5 = 11
                * **P4**: CT = 10, TAT = 10 - 3 = 7, WT = 7 - 2 = 5
                * **P5**: CT = 20, TAT = 20 - 5 = 15, WT = 15 - 6 = 9
                
                **Averages**:
                * **Average Turnaround Time (TAT)**: (8 + 10 + 16 + 7 + 15) / 5 = **11.20 time units**
                * **Average Waiting Time (WT)**: (4 + 7 + 11 + 5 + 9) / 5 = **7.20 time units**
                """.trimIndent()
            }
            lower.contains("paging") || lower.contains("ram") || lower.contains("page table") || lower.contains("frame") || lower.contains("fault") || lower.contains("fifo") || lower.contains("lru") -> {
                """
                ### 🧠 Memory Paging & Address Translation Analysis
                
                **1. System Specifications & Formula Breakdown**:
                * **RAM (Physical Memory)** = 4 GB = 4 × 1024 × 1024 × 1024 B = 2³² Bytes → **32-bit Physical Address**
                * **Page Size** = 4 KB = 4 × 1024 B = 4,096 Bytes = 2¹² Bytes → **12-bit Page Offset (d)**
                * **Logical Space** = 32 MB = 32 × 1024 × 1024 B = 2²⁵ Bytes → **25-bit Logical Address**
                
                **Key Calculations**:
                * **Total Pages in Logical Space**:
                  Total Pages = 32 MB / 4 KB = 2²⁵ / 2¹² = 2¹³ = **8,192 Pages**
                  *(Requires 13 bits for Page Number p)*
                * **Total Frames in Physical RAM**:
                  Total Frames = 4 GB / 4 KB = 2³² / 2¹² = 2²⁰ = **1,048,576 Frames**
                  *(Requires 20 bits for Frame Number f)*
                
                **2. Address Translation Process**:
                * Given logical address = [Page Number p (13 bits) | Offset d (12 bits)]
                * Hardware MMU consults Page Table at index p:
                  * If **Valid bit = 1**: Physical Address = [Frame Number f (20 bits) | Offset d (12 bits)] = (f × 4096) + d.
                  * If **Valid bit = 0**: Trap to OS → **Page Fault**, page must be fetched from disk swap space into one of the 3 allocated frames!
                
                **3. FIFO vs LRU Page Replacement (3 Frames)**:
                * **FIFO**: Evicts page that arrived earliest in RAM. Suffers from Belady's Anomaly.
                * **LRU**: Evicts page that hasn't been referenced for the longest time. Generally achieves higher hit ratio.
                """.trimIndent()
            }
            lower.contains("disk") || lower.contains("route") || lower.contains("fcfs") || lower.contains("sstf") || lower.contains("scan") || lower.contains("seek") -> {
                """
                ### 🛵 Delivery Route Optimization (Disk Scheduling Comparison)
                
                **Setup**: Cylinder Range = 0 to 100 | Initial Head = **40** | Queue = `[55, 18, 90, 66, 32, 75]`
                
                **1. FCFS (First-Come, First-Served)**:
                * Serves in arrival order: 40 → 55 → 18 → 90 → 66 → 32 → 75
                * Seek hops: |55-40| (15) + |18-55| (37) + |90-18| (72) + |66-90| (24) + |32-66| (34) + |75-32| (43)
                * **Total Seek Distance** = **225 cylinders** (Avg: 37.5 cyl)
                * *Evaluation*: Wild oscillations back and forth across the city zones.
                
                **2. SSTF (Shortest Seek Time First)**:
                * Greedily picks the nearest delivery cylinder:
                  * From 40 → nearest is **32** (diff 8)
                  * From 32 → nearest is **18** (diff 14)
                  * From 18 → nearest is **55** (diff 37)
                  * From 55 → nearest is **66** (diff 11)
                  * From 66 → nearest is **75** (diff 9)
                  * From 75 → nearest is **90** (diff 15)
                * **Path**: 40 → 32 → 18 → 55 → 66 → 75 → 90
                * **Total Seek Distance** = 8 + 14 + 37 + 11 + 9 + 15 = **94 cylinders** (Avg: 15.67 cyl)
                * *Evaluation*: **58.2% more efficient** than FCFS!
                
                **3. SCAN (Elevator Algorithm - Direction: High)**:
                * Sweeps towards 100 first, servicing requests, reaches boundary 100, then sweeps down:
                * **Path**: 40 → 55 → 66 → 75 → 90 → 100 → 32 → 18
                * **Total Seek Distance** = (100 - 40) + (100 - 18) = 60 + 82 = **142 cylinders** (Avg: 23.67 cyl)
                * *Evaluation*: Prevents starvation compared to SSTF while providing predictable delivery throughput.
                """.trimIndent()
            }
            else -> {
                """
                ### 🚀 Food Delivery Operating System Simulator
                
                This simulator demonstrates fundamental Computer Science & Operating System mechanics mapped to real-world on-demand food logistics:
                
                1. **Order Processing (CPU Scheduling)**:
                   * How an order dispatch engine schedules multi-stage meal preparation on kitchen stations using **Round Robin (Quantum = 2)**.
                
                2. **Memory Allocation (Paging)**:
                   * Translating virtual order/catalog addresses into physical RAM frames ($32\text{MB}$ logical space $\rightarrow$ $8,192$ pages, $4\text{GB}$ physical RAM $\rightarrow$ $1,048,576$ frames) with FIFO & LRU page replacement.
                
                3. **Delivery Route Optimization (Disk Head Scheduling)**:
                   * Minimizing courier travel distance across street cylinder blocks ($0\text{--}100$) using **FCFS**, **SSTF**, and **SCAN**.
                
                Ask any question or tap one of the quick question chips to dive deeper!
                """.trimIndent()
            }
        }
    }
}
