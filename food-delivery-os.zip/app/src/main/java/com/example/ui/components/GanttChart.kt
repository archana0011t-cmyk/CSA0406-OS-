package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DividerDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.GanttBlock
import com.example.model.ProcessMetrics
import com.example.model.RoundRobinResult
import com.example.model.SimulationStep
import com.example.ui.theme.EmeraldTertiary
import com.example.ui.theme.HitGreen
import com.example.ui.theme.OrangeAccent
import com.example.ui.theme.OrangeBorderLight
import com.example.ui.theme.OrangeContainerLight
import com.example.ui.theme.OrangePrimary
import com.example.ui.theme.Slate100
import com.example.ui.theme.Slate500
import com.example.ui.theme.Slate800
import com.example.ui.theme.Slate900

@Composable
fun GanttChartSection(
    rrResult: RoundRobinResult,
    currentStepIndex: Int,
    isPlaying: Boolean,
    onTogglePlay: () -> Unit,
    onStepChange: (Int) -> Unit,
    onQuantumChange: (Int) -> Unit,
    onReset: () -> Unit,
    modifier: Modifier = Modifier
) {
    val steps = rrResult.steps
    val currentStep = steps.getOrNull(currentStepIndex) ?: steps.lastOrNull()
    val currentTime = currentStep?.time ?: rrResult.totalTime

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("gantt_chart_card"),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        shape = RoundedCornerShape(24.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, OrangeBorderLight),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp)
        ) {
            // Header with Live Indicator & Quantum Control
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(HitGreen)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "Order Processing (Round Robin)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.ExtraBold,
                            color = Slate800
                        )
                        Text(
                            text = "Interactive Gantt Chart | P1–P5 (Quantum = ${rrResult.quantum})",
                            style = MaterialTheme.typography.bodySmall,
                            color = Slate500
                        )
                    }
                }

                // Quantum Selector Chip
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = Slate100,
                    border = androidx.compose.foundation.BorderStroke(1.dp, OrangeBorderLight),
                    modifier = Modifier.testTag("quantum_selector")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                    ) {
                        IconButton(
                            onClick = { if (rrResult.quantum > 1) onQuantumChange(rrResult.quantum - 1) },
                            modifier = Modifier.size(26.dp).testTag("quantum_decrease")
                        ) {
                            Icon(Icons.Default.Remove, contentDescription = "Decrease Quantum", modifier = Modifier.size(14.dp), tint = Slate800)
                        }

                        Text(
                            text = "Q = ${rrResult.quantum}",
                            style = MaterialTheme.typography.labelMedium,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.ExtraBold,
                            color = OrangeAccent,
                            modifier = Modifier.padding(horizontal = 4.dp)
                        )

                        IconButton(
                            onClick = { if (rrResult.quantum < 8) onQuantumChange(rrResult.quantum + 1) },
                            modifier = Modifier.size(26.dp).testTag("quantum_increase")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = "Increase Quantum", modifier = Modifier.size(14.dp), tint = Slate800)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Interactive Horizontal Gantt Chart Canvas
            val scrollState = rememberScrollState()
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(OrangeContainerLight.copy(alpha = 0.5f))
                    .border(1.dp, OrangeBorderLight, RoundedCornerShape(16.dp))
                    .padding(vertical = 14.dp, horizontal = 10.dp)
            ) {
                Column(
                    modifier = Modifier.horizontalScroll(scrollState)
                ) {
                    // Timeline Blocks
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        rrResult.ganttBlocks.forEachIndexed { index, block ->
                            val isExecuted = block.endTime <= currentTime
                            val isCurrent = block.startTime < currentTime && block.endTime >= currentTime
                            GanttBlockItem(
                                block = block,
                                isExecuted = isExecuted,
                                isCurrent = isCurrent
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Timeline Time Marks
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "0",
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = Slate500,
                            modifier = Modifier.width(16.dp)
                        )
                        rrResult.ganttBlocks.forEach { block ->
                            val duration = block.endTime - block.startTime
                            val blockWidth = (duration * 40).dp
                            Text(
                                text = "${block.endTime}",
                                style = MaterialTheme.typography.labelSmall,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.End,
                                color = if (block.endTime <= currentTime) OrangeAccent else Slate500,
                                modifier = Modifier.width(blockWidth)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Playback controls & Step slider
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = { if (currentStepIndex > 0) onStepChange(currentStepIndex - 1) },
                        modifier = Modifier.size(36.dp).testTag("step_backward")
                    ) {
                        Icon(Icons.Default.FastRewind, contentDescription = "Step Back", tint = OrangeAccent)
                    }

                    IconButton(
                        onClick = onTogglePlay,
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(OrangePrimary)
                            .testTag("play_pause_rr")
                    ) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = if (isPlaying) "Pause" else "Play",
                            tint = Color.White
                        )
                    }

                    IconButton(
                        onClick = { if (currentStepIndex < steps.size - 1) onStepChange(currentStepIndex + 1) },
                        modifier = Modifier.size(36.dp).testTag("step_forward")
                    ) {
                        Icon(Icons.Default.FastForward, contentDescription = "Step Next", tint = OrangeAccent)
                    }

                    IconButton(
                        onClick = onReset,
                        modifier = Modifier.size(36.dp).testTag("reset_rr")
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = "Reset", tint = Slate500)
                    }
                }

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = OrangeContainerLight
                ) {
                    Text(
                        text = "Time t = $currentTime / ${rrResult.totalTime} units",
                        style = MaterialTheme.typography.labelMedium,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.ExtraBold,
                        color = OrangeAccent,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            // Step Slider
            Slider(
                value = currentStepIndex.toFloat(),
                onValueChange = { onStepChange(it.toInt()) },
                valueRange = 0f..maxOf(0, steps.size - 1).toFloat(),
                steps = if (steps.size > 2) steps.size - 2 else 0,
                colors = SliderDefaults.colors(
                    thumbColor = OrangePrimary,
                    activeTrackColor = OrangePrimary,
                    inactiveTrackColor = OrangeBorderLight
                ),
                modifier = Modifier.fillMaxWidth().testTag("rr_timeline_slider")
            )

            // Current Step Status Description
            if (currentStep != null) {
                Surface(
                    color = OrangeContainerLight,
                    shape = RoundedCornerShape(14.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, OrangeBorderLight),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = currentStep.description,
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.SemiBold,
                            color = Slate800
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Ready Queue: ",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.ExtraBold,
                                color = OrangeAccent
                            )
                            if (currentStep.readyQueue.isEmpty()) {
                                Text(
                                    text = "[Empty]",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Slate500
                                )
                            } else {
                                currentStep.readyQueue.forEach { pid ->
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = MaterialTheme.colorScheme.surface,
                                        border = androidx.compose.foundation.BorderStroke(1.dp, OrangeBorderLight),
                                        modifier = Modifier.padding(horizontal = 3.dp)
                                    ) {
                                        Text(
                                            text = pid,
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = OrangeAccent,
                                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Metrics Summary Cards
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MetricCard(
                    title = "Avg Turnaround (TAT)",
                    value = String.format("%.2f", rrResult.averageTurnaroundTime) + " u",
                    subtitle = "Formula: Σ (CT - AT) / N",
                    modifier = Modifier.weight(1f)
                )
                MetricCard(
                    title = "Avg Waiting Time (WT)",
                    value = String.format("%.2f", rrResult.averageWaitingTime) + " u",
                    subtitle = "Formula: Σ (TAT - BT) / N",
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Process Metrics Table
            Text(
                text = "Process Execution & Metrics Table",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.ExtraBold,
                color = Slate800
            )

            Spacer(modifier = Modifier.height(8.dp))

            ProcessMetricsTable(
                metrics = rrResult.metrics,
                currentRunningProcId = currentStep?.runningProcessId
            )
        }
    }
}

@Composable
private fun GanttBlockItem(
    block: GanttBlock,
    isExecuted: Boolean,
    isCurrent: Boolean
) {
    val duration = block.endTime - block.startTime
    val width = (duration * 40).dp
    val blockColor by animateColorAsState(
        targetValue = if (isCurrent) block.color else if (isExecuted) block.color.copy(alpha = 0.9f) else block.color.copy(alpha = 0.35f),
        label = "blockColor"
    )

    Box(
        modifier = Modifier
            .width(width)
            .height(52.dp)
            .padding(horizontal = 2.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(blockColor)
            .border(
                width = if (isCurrent) 2.dp else 1.dp,
                color = if (isCurrent) Color.White else Color.Black.copy(alpha = 0.12f),
                shape = RoundedCornerShape(10.dp)
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = block.processId,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Black,
                color = if (block.processId == "P3" || block.processId == "P2") Slate900 else Color.White
            )
            Text(
                text = "${block.startTime}–${block.endTime}",
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = if (block.processId == "P3" || block.processId == "P2") Slate800 else Color.White.copy(alpha = 0.95f)
            )
        }
    }
}

@Composable
private fun MetricCard(
    title: String,
    value: String,
    subtitle: String,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        color = OrangeContainerLight,
        border = androidx.compose.foundation.BorderStroke(1.dp, OrangeBorderLight)
    ) {
        Column(
            modifier = Modifier.padding(14.dp)
        ) {
            Text(
                text = title.uppercase(),
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, letterSpacing = 0.8.sp),
                fontWeight = FontWeight.Bold,
                color = Slate500
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Black,
                color = OrangeAccent
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 10.sp),
                color = Slate500
            )
        }
    }
}

@Composable
fun ProcessMetricsTable(
    metrics: List<ProcessMetrics>,
    currentRunningProcId: String?
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(OrangeContainerLight.copy(alpha = 0.35f))
            .border(1.dp, OrangeBorderLight, RoundedCornerShape(14.dp))
    ) {
        // Table Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(OrangeContainerLight)
                .padding(horizontal = 8.dp, vertical = 9.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("Order", modifier = Modifier.weight(1.3f), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = Slate800)
            Text("AT", modifier = Modifier.weight(0.7f), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, color = Slate800)
            Text("BT", modifier = Modifier.weight(0.7f), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, color = Slate800)
            Text("CT", modifier = Modifier.weight(0.7f), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, color = Slate800)
            Text("TAT", modifier = Modifier.weight(0.8f), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, color = Slate800)
            Text("WT", modifier = Modifier.weight(0.8f), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, color = Slate800)
        }

        HorizontalDivider(color = OrangeBorderLight)

        metrics.forEach { item ->
            val isCurrent = item.id == currentRunningProcId
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(if (isCurrent) OrangePrimary.copy(alpha = 0.15f) else Color.Transparent)
                    .padding(horizontal = 8.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier.weight(1.3f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(item.color)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = item.id,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = Slate800
                    )
                }

                Text("${item.arrivalTime}", modifier = Modifier.weight(0.7f), style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center, color = Slate800)
                Text("${item.burstTime}", modifier = Modifier.weight(0.7f), style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center, color = Slate800)
                Text("${item.completionTime}", modifier = Modifier.weight(0.7f), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, color = Slate800)
                Text("${item.turnaroundTime}", modifier = Modifier.weight(0.8f), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.ExtraBold, color = OrangeAccent, textAlign = TextAlign.Center)
                Text("${item.waitingTime}", modifier = Modifier.weight(0.8f), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.ExtraBold, color = EmeraldTertiary, textAlign = TextAlign.Center)
            }
            HorizontalDivider(color = OrangeBorderLight.copy(alpha = 0.6f))
        }
    }
}

