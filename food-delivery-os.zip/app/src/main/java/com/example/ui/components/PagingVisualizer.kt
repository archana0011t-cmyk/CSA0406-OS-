package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DividerDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AddressTranslationResult
import com.example.model.PageReplacementResult
import com.example.model.PageTableEntry
import com.example.model.PagingSpec
import com.example.ui.theme.BlueMemory
import com.example.ui.theme.BlueMemoryBorder
import com.example.ui.theme.BlueMemoryDark
import com.example.ui.theme.BlueMemoryLight
import com.example.ui.theme.FaultRed
import com.example.ui.theme.HitGreen
import com.example.ui.theme.Slate100
import com.example.ui.theme.Slate500
import com.example.ui.theme.Slate800

@Composable
fun PagingVisualizerSection(
    spec: PagingSpec,
    pageTable: List<PageTableEntry>,
    referenceString: List<Int>,
    fifoResult: PageReplacementResult,
    lruResult: PageReplacementResult,
    activeAlgo: String,
    currentStepIndex: Int,
    inputPage: String,
    inputOffset: String,
    translationResult: AddressTranslationResult?,
    onSelectAlgo: (String) -> Unit,
    onStepChange: (Int) -> Unit,
    onTranslationInputsChange: (String, String) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Calculations & Formula Derivation Card
        Card(
            modifier = Modifier.fillMaxWidth().testTag("paging_formulas_card"),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(24.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, BlueMemoryBorder),
            elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(BlueMemory)
                    )
                    Column {
                        Text(
                            text = "Memory Allocation & Paging Calculus",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.ExtraBold,
                            color = Slate800
                        )
                        Text(
                            text = "Physical RAM (4GB) | Page Size (4KB) | Logical Space (32MB)",
                            style = MaterialTheme.typography.bodySmall,
                            color = Slate500
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Formula Metric Cards
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    CalculationBox(
                        title = "Total Pages (Logical)",
                        value = "8,192 Pages",
                        formula = "32 MB / 4 KB = 2²⁵ / 2¹² = 2¹³",
                        bits = "13-bit Page # + 12-bit Offset = 25 bits",
                        modifier = Modifier.weight(1f)
                    )
                    CalculationBox(
                        title = "Total Frames (Physical)",
                        value = "1,048,576 Frames",
                        formula = "4 GB / 4 KB = 2³² / 2¹² = 2²⁰",
                        bits = "20-bit Frame # + 12-bit Offset = 32 bits",
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = BlueMemoryLight,
                    border = androidx.compose.foundation.BorderStroke(1.dp, BlueMemoryBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Allocated RAM Frames: 3 Frames (Frame #104, #512, #890)",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold,
                            color = BlueMemoryDark
                        )
                    }
                }
            }
        }

        // 2. Interactive Page Fault Tracker (FIFO vs LRU)
        Card(
            modifier = Modifier.fillMaxWidth().testTag("page_fault_tracker_card"),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(24.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, BlueMemoryBorder),
            elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Page Fault Tracker (FIFO vs LRU)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.ExtraBold,
                            color = Slate800
                        )
                        Text(
                            text = "Reference String: ${referenceString.joinToString(", ")}",
                            style = MaterialTheme.typography.bodySmall,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = BlueMemory
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Algorithm Toggle Chips
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = activeAlgo == "FIFO",
                        onClick = { onSelectAlgo("FIFO") },
                        shape = RoundedCornerShape(16.dp),
                        label = { Text("FIFO (${fifoResult.totalFaults} Faults)", fontWeight = if (activeAlgo == "FIFO") FontWeight.Bold else FontWeight.Normal) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = BlueMemory,
                            selectedLabelColor = Color.White
                        ),
                        modifier = Modifier.testTag("chip_fifo")
                    )
                    FilterChip(
                        selected = activeAlgo == "LRU",
                        onClick = { onSelectAlgo("LRU") },
                        shape = RoundedCornerShape(16.dp),
                        label = { Text("LRU (${lruResult.totalFaults} Faults)", fontWeight = if (activeAlgo == "LRU") FontWeight.Bold else FontWeight.Normal) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = BlueMemory,
                            selectedLabelColor = Color.White
                        ),
                        modifier = Modifier.testTag("chip_lru")
                    )
                    FilterChip(
                        selected = activeAlgo == "COMPARE",
                        onClick = { onSelectAlgo("COMPARE") },
                        shape = RoundedCornerShape(16.dp),
                        label = { Text("Compare Both", fontWeight = if (activeAlgo == "COMPARE") FontWeight.Bold else FontWeight.Normal) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = BlueMemory,
                            selectedLabelColor = Color.White
                        ),
                        modifier = Modifier.testTag("chip_compare")
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Comparison stats card
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    StatBadge(
                        title = "FIFO Algorithm",
                        faults = "${fifoResult.totalFaults} Faults",
                        hits = "${fifoResult.totalHits} Hits (${String.format("%.1f", fifoResult.hitRate)}%)",
                        isBest = fifoResult.totalFaults <= lruResult.totalFaults,
                        modifier = Modifier.weight(1f)
                    )
                    StatBadge(
                        title = "LRU Algorithm",
                        faults = "${lruResult.totalFaults} Faults",
                        hits = "${lruResult.totalHits} Hits (${String.format("%.1f", lruResult.hitRate)}%)",
                        isBest = lruResult.totalFaults <= fifoResult.totalFaults,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Step-by-step visual matrix for selected algorithm
                val currentResult = if (activeAlgo == "LRU") lruResult else fifoResult
                Text(
                    text = "${if (activeAlgo == "COMPARE") "FIFO Matrix" else currentResult.algorithmName} Step-by-Step State Matrix:",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = Slate800
                )

                Spacer(modifier = Modifier.height(8.dp))

                val scrollState = rememberScrollState()
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(BlueMemoryLight.copy(alpha = 0.5f))
                        .border(1.dp, BlueMemoryBorder, RoundedCornerShape(16.dp))
                        .padding(10.dp)
                        .horizontalScroll(scrollState),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    // Frame Header Column
                    Column(
                        verticalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier.padding(end = 4.dp)
                    ) {
                        Text("Ref", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = Slate800, modifier = Modifier.height(28.dp))
                        Text("F0", style = MaterialTheme.typography.labelSmall, color = Slate500, modifier = Modifier.height(28.dp))
                        Text("F1", style = MaterialTheme.typography.labelSmall, color = Slate500, modifier = Modifier.height(28.dp))
                        Text("F2", style = MaterialTheme.typography.labelSmall, color = Slate500, modifier = Modifier.height(28.dp))
                        Text("Stat", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = Slate800, modifier = Modifier.height(22.dp))
                    }

                    // Steps Columns
                    currentResult.steps.forEachIndexed { index, step ->
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            // Referenced Page Box
                            Box(
                                modifier = Modifier
                                    .size(28.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(BlueMemory),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "${step.pageReferenced}",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }

                            // Frame 0
                            FrameCell(value = step.framesState.getOrNull(0))
                            // Frame 1
                            FrameCell(value = step.framesState.getOrNull(1))
                            // Frame 2
                            FrameCell(value = step.framesState.getOrNull(2))

                            // Hit/Fault Badge
                            Box(
                                modifier = Modifier
                                    .size(22.dp)
                                    .clip(CircleShape)
                                    .background(if (step.isHit) HitGreen else FaultRed),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = if (step.isHit) "H" else "F",
                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color.White
                                )
                            }
                        }
                    }
                }
            }
        }

        // 3. Visual Page Table & Address Translation
        Card(
            modifier = Modifier.fillMaxWidth().testTag("page_table_card"),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(24.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, BlueMemoryBorder),
            elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text(
                    text = "Food App Visual Page Table",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.ExtraBold,
                    color = Slate800
                )
                Text(
                    text = "Mapping 8 Food App Pages (32MB) to 4GB RAM Frame Numbers",
                    style = MaterialTheme.typography.bodySmall,
                    color = Slate500
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Page Table List
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(BlueMemoryLight.copy(alpha = 0.35f))
                        .border(1.dp, BlueMemoryBorder, RoundedCornerShape(14.dp))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(BlueMemoryLight)
                            .padding(horizontal = 8.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Page #", modifier = Modifier.weight(0.7f), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = Slate800)
                        Text("Food App Module", modifier = Modifier.weight(1.6f), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = Slate800)
                        Text("Frame #", modifier = Modifier.weight(0.9f), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, color = Slate800)
                        Text("Valid Bit", modifier = Modifier.weight(0.8f), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, color = Slate800)
                    }

                    HorizontalDivider(color = BlueMemoryBorder)

                    pageTable.forEach { entry ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 8.dp, vertical = 7.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("P${entry.pageNumber}", modifier = Modifier.weight(0.7f), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = Slate800)
                            Text(entry.moduleName, modifier = Modifier.weight(1.6f), style = MaterialTheme.typography.bodySmall, color = Slate800)
                            Text(
                                text = entry.frameNumber?.let { "F#$it" } ?: "Disk Swap",
                                modifier = Modifier.weight(0.9f),
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = if (entry.isValid) FontWeight.Bold else FontWeight.Normal,
                                color = if (entry.isValid) BlueMemory else Slate500,
                                textAlign = TextAlign.Center
                            )
                            Box(
                                modifier = Modifier.weight(0.8f),
                                contentAlignment = Alignment.Center
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = if (entry.isValid) HitGreen.copy(alpha = 0.15f) else FaultRed.copy(alpha = 0.15f)
                                ) {
                                    Text(
                                        text = if (entry.isValid) "1 (Valid)" else "0 (Invalid)",
                                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                                        fontWeight = FontWeight.Bold,
                                        color = if (entry.isValid) HitGreen else FaultRed,
                                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                        HorizontalDivider(color = BlueMemoryBorder.copy(alpha = 0.5f))
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Address Translation Playground
                Text(
                    text = "Hardware MMU Address Translation",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.ExtraBold,
                    color = Slate800
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = inputPage,
                        onValueChange = { onTranslationInputsChange(it, inputOffset) },
                        label = { Text("Page # (0-7)") },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = BlueMemory,
                            unfocusedBorderColor = BlueMemoryBorder
                        ),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f).testTag("input_page_number")
                    )
                    OutlinedTextField(
                        value = inputOffset,
                        onValueChange = { onTranslationInputsChange(inputPage, it) },
                        label = { Text("Offset d (0-4095)") },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = BlueMemory,
                            unfocusedBorderColor = BlueMemoryBorder
                        ),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f).testTag("input_page_offset")
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                if (translationResult != null) {
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = if (translationResult.isValid) BlueMemoryLight else MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (translationResult.isValid) BlueMemoryBorder else MaterialTheme.colorScheme.error),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            if (translationResult.isValid) {
                                Text(
                                    text = "✓ Physical Address Generated: ${translationResult.physicalAddress} Bytes",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = BlueMemoryDark
                                )
                                Text(
                                    text = "Formula: (Frame #${translationResult.frameNumber} × 4096) + Offset ${translationResult.offset} = (${translationResult.frameNumber} × 4096) + ${translationResult.offset}",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontFamily = FontFamily.Monospace,
                                    color = Slate800
                                )
                            } else {
                                Text(
                                    text = "⚠️ ${translationResult.errorMessage}",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onErrorContainer
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FrameCell(value: Int?) {
    Box(
        modifier = Modifier
            .size(28.dp)
            .clip(RoundedCornerShape(4.dp))
            .background(if (value != null) MaterialTheme.colorScheme.surface else Color.Transparent)
            .border(
                1.dp,
                if (value != null) BlueMemoryBorder else Color.Transparent,
                RoundedCornerShape(4.dp)
            ),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = value?.toString() ?: "-",
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.SemiBold,
            color = if (value != null) Slate800 else Slate500.copy(alpha = 0.4f)
        )
    }
}

@Composable
private fun CalculationBox(
    title: String,
    value: String,
    formula: String,
    bits: String,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        color = BlueMemoryLight,
        border = androidx.compose.foundation.BorderStroke(1.dp, BlueMemoryBorder)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(
                text = title.uppercase(),
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, letterSpacing = 0.8.sp),
                fontWeight = FontWeight.Bold,
                color = Slate500
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Black,
                color = BlueMemory
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = formula,
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 10.sp),
                fontFamily = FontFamily.Monospace,
                color = Slate800
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = bits,
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 9.sp),
                color = Slate500
            )
        }
    }
}

@Composable
private fun StatBadge(
    title: String,
    faults: String,
    hits: String,
    isBest: Boolean,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        color = BlueMemoryLight,
        border = if (isBest) androidx.compose.foundation.BorderStroke(1.5.dp, HitGreen) else androidx.compose.foundation.BorderStroke(1.dp, BlueMemoryBorder)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(title, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = Slate800)
                if (isBest) {
                    Text("Optimal", style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp), color = HitGreen, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(faults, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.ExtraBold, color = FaultRed)
            Text(hits, style = MaterialTheme.typography.bodySmall.copy(fontSize = 10.sp), color = HitGreen, fontWeight = FontWeight.Bold)
        }
    }
}

