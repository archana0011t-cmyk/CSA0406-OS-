package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Vibrant Palette - DelivOS Brand Core
val OrangePrimary = Color(0xFFF97316) // Orange 500
val OrangePrimaryDark = Color(0xFFFB923C) // Orange 400
val OrangeAccent = Color(0xFFEA580C) // Orange 600
val OrangeContainerLight = Color(0xFFFFF1EB) // Orange 50
val OrangeContainerDark = Color(0xFF431407)
val OrangeBorderLight = Color(0xFFFFEDD5) // Orange 100

// Memory Blue Accent
val BlueMemory = Color(0xFF2563EB) // Blue 600
val BlueMemoryDark = Color(0xFF1E40AF) // Blue 800
val BlueMemoryLight = Color(0xFFEFF6FF) // Blue 50
val BlueMemoryBorder = Color(0xFFDBEAFE) // Blue 100
val BlueMemoryBar = Color(0xFF3B82F6) // Blue 500

// Route Purple Accent
val PurpleRoute = Color(0xFFA855F7) // Purple 500
val PurpleRouteDark = Color(0xFF7E22CE) // Purple 700
val PurpleRouteLight = Color(0xFFFAF5FF) // Purple 50
val PurpleRouteBorder = Color(0xFFF3E8FF) // Purple 100

// Aliases for disk visualizer
val PurpleDisk = PurpleRoute
val PurpleDiskDark = PurpleRouteDark
val PurpleContainerLight = PurpleRouteLight
val PurpleBorderLight = PurpleRouteBorder
val CyanSecondary = Color(0xFF06B6D4)

// Slate AI Dark
val Slate900 = Color(0xFF0F172A)
val Slate800 = Color(0xFF1E293B)
val Slate700 = Color(0xFF334155)
val Slate500 = Color(0xFF64748B)
val Slate400 = Color(0xFF94A3B8)
val Slate200 = Color(0xFFE2E8F0)
val Slate100 = Color(0xFFF1F5F9)

val EmeraldTertiary = Color(0xFF10B981) // Emerald 500
val EmeraldTertiaryDark = Color(0xFF34D399)
val EmeraldContainerLight = Color(0xFFECFDF5)
val EmeraldContainerDark = Color(0xFF064E3B)

// Canvas & Surfaces (Vibrant Palette Theme)
val BackgroundLight = Color(0xFFFFF8F6) // Warm off-white #FFF8F6
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFFFF1EB) // Soft warm tint
val OnSurfaceLight = Color(0xFF1E293B) // Slate 800
val OnSurfaceVariantLight = Color(0xFF64748B) // Slate 500

val BackgroundDark = Color(0xFF0F172A) // Slate 900
val SurfaceDark = Color(0xFF1E293B) // Slate 800
val SurfaceVariantDark = Color(0xFF334155) // Slate 700
val OnSurfaceDark = Color(0xFFF8FAFC)
val OnSurfaceVariantDark = Color(0xFF94A3B8)

// OS Process Palette (Vibrant Food Delivery)
val ProcessP1 = Color(0xFFFB923C) // Orange 400
val ProcessP2 = Color(0xFFFDBA74) // Orange 300
val ProcessP3 = Color(0xFFFED7AA) // Orange 200
val ProcessP4 = Color(0xFF38BDF8) // Sky 400
val ProcessP5 = Color(0xFFA855F7) // Purple 500
val ProcessP6 = Color(0xFF34D399) // Emerald 400
val IdleColor = Color(0xFF94A3B8)

// Status & Metric Colors
val HitGreen = Color(0xFF10B981)
val FaultRed = Color(0xFFEF4444)
val ChartLineColor = Color(0xFFA855F7) // Purple route
val ChartGridColor = Color(0x22A855F7)

