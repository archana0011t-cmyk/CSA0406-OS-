package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.TwoWheeler
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedFilterChip
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.AiTutorSection
import com.example.ui.components.DiskLineChartSection
import com.example.ui.components.GanttChartSection
import com.example.ui.components.PagingVisualizerSection
import com.example.ui.theme.BlueMemory
import com.example.ui.theme.BlueMemoryBorder
import com.example.ui.theme.EmeraldTertiary
import com.example.ui.theme.OrangeAccent
import com.example.ui.theme.OrangeBorderLight
import com.example.ui.theme.OrangeContainerLight
import com.example.ui.theme.OrangePrimary
import com.example.ui.theme.PurpleRoute
import com.example.ui.theme.PurpleRouteBorder
import com.example.ui.theme.Slate800
import com.example.ui.theme.Slate900
import com.example.viewmodel.DashboardTab
import com.example.viewmodel.OsSimulatorViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    viewModel: OsSimulatorViewModel,
    modifier: Modifier = Modifier
) {
    val state by viewModel.uiState.collectAsState()

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(
                                    Brush.linearGradient(
                                        listOf(OrangePrimary, OrangeAccent)
                                    )
                                )
                                .shadow(elevation = 4.dp, shape = CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Default.Restaurant,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "OS SIMULATOR",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    letterSpacing = 1.8.sp,
                                    fontSize = 9.sp
                                ),
                                fontWeight = FontWeight.Black,
                                color = OrangeAccent
                            )
                            Text(
                                text = "DelivOS v2.0",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Black,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                },
                actions = {
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = OrangeContainerLight,
                        border = androidx.compose.foundation.BorderStroke(1.dp, OrangeBorderLight),
                        modifier = Modifier.padding(end = 8.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = OrangeAccent,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(5.dp))
                            Text(
                                text = "Gemini AI Tutor",
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp),
                                fontWeight = FontWeight.Bold,
                                color = OrangeAccent
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Navigation Section Tabs / Chips
            item {
                val chipScrollState = rememberScrollState()
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(chipScrollState),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    DashboardTab.values().forEach { tab ->
                        val isSelected = state.currentTab == tab
                        ElevatedFilterChip(
                            selected = isSelected,
                            onClick = { viewModel.selectTab(tab) },
                            shape = RoundedCornerShape(20.dp),
                            label = {
                                Text(
                                    text = tab.title,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    fontSize = 12.sp
                                )
                            },
                            leadingIcon = {
                                val icon = when (tab) {
                                    DashboardTab.OVERVIEW -> Icons.Default.Dashboard
                                    DashboardTab.ROUND_ROBIN -> Icons.Default.Speed
                                    DashboardTab.MEMORY_PAGING -> Icons.Default.Memory
                                    DashboardTab.DISK_SCHEDULING -> Icons.Default.TwoWheeler
                                    DashboardTab.AI_TUTOR -> Icons.Default.AutoAwesome
                                }
                                Icon(icon, contentDescription = null, modifier = Modifier.size(16.dp))
                            },
                            colors = FilterChipDefaults.elevatedFilterChipColors(
                                selectedContainerColor = OrangePrimary,
                                selectedLabelColor = Color.White,
                                selectedLeadingIconColor = Color.White,
                                containerColor = MaterialTheme.colorScheme.surface
                            ),
                            modifier = Modifier.testTag("tab_${tab.name.lowercase()}")
                        )
                    }
                }
            }

            // Overview Highlights (when OVERVIEW is selected)
            if (state.currentTab == DashboardTab.OVERVIEW) {
                item {
                    OverviewHeroCard(
                        onExploreConcept = { viewModel.selectTab(it) }
                    )
                }
            }

            // 1. Order Processing (Round Robin) Section
            if (state.currentTab == DashboardTab.OVERVIEW || state.currentTab == DashboardTab.ROUND_ROBIN) {
                item {
                    GanttChartSection(
                        rrResult = state.rrResult,
                        currentStepIndex = state.rrStepIndex,
                        isPlaying = state.isRrPlaying,
                        onTogglePlay = { viewModel.toggleRrPlayback() },
                        onStepChange = { viewModel.setRrStep(it) },
                        onQuantumChange = { viewModel.setQuantum(it) },
                        onReset = { viewModel.resetRrSimulation() }
                    )
                }
            }

            // 2. Memory Allocation (Paging) Section
            if (state.currentTab == DashboardTab.OVERVIEW || state.currentTab == DashboardTab.MEMORY_PAGING) {
                item {
                    PagingVisualizerSection(
                        spec = state.pagingSpec,
                        pageTable = state.pageTable,
                        referenceString = state.referenceString,
                        fifoResult = state.fifoResult,
                        lruResult = state.lruResult,
                        activeAlgo = state.pagingActiveAlgo,
                        currentStepIndex = state.pagingStepIndex,
                        inputPage = state.inputPageNum,
                        inputOffset = state.inputOffset,
                        translationResult = state.translationResult,
                        onSelectAlgo = { viewModel.setPagingActiveAlgo(it) },
                        onStepChange = { viewModel.setPagingStep(it) },
                        onTranslationInputsChange = { page, offset ->
                            viewModel.updateTranslationInputs(page, offset)
                        }
                    )
                }
            }

            // 3. Delivery Route Optimization (Disk Scheduling) Section
            if (state.currentTab == DashboardTab.OVERVIEW || state.currentTab == DashboardTab.DISK_SCHEDULING) {
                item {
                    DiskLineChartSection(
                        selectedAlgo = state.selectedDiskAlgo,
                        currentResult = viewModel.getCurrentDiskResult(),
                        fcfsResult = state.fcfsResult,
                        sstfResult = state.sstfResult,
                        scanResult = state.scanResult,
                        lookResult = state.lookResult,
                        currentStepIndex = state.diskStepIndex,
                        isPlaying = state.isDiskPlaying,
                        scanDirection = state.diskDirection,
                        onSelectAlgo = { viewModel.selectDiskAlgorithm(it) },
                        onStepChange = { viewModel.setDiskStep(it) },
                        onTogglePlay = { viewModel.toggleDiskPlayback() },
                        onDirectionChange = { viewModel.setScanDirection(it) }
                    )
                }
            }

            // 4. AI Assistant Section (Gemini)
            if (state.currentTab == DashboardTab.OVERVIEW || state.currentTab == DashboardTab.AI_TUTOR) {
                item {
                    AiTutorSection(
                        chatMessages = state.chatMessages,
                        isAiThinking = state.isAiThinking,
                        isApiKeyConfigured = state.isApiKeyConfigured,
                        onSendMessage = { viewModel.askAiTutor(it) }
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun OverviewHeroCard(
    onExploreConcept: (DashboardTab) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = OrangeContainerLight),
        border = androidx.compose.foundation.BorderStroke(1.dp, OrangeBorderLight),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "🍔 FOOD LOGISTICS OS ENGINE",
                    style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.2.sp),
                    fontWeight = FontWeight.Black,
                    color = OrangeAccent
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Experience OS Scheduling & Algorithms in Real-Time",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.ExtraBold,
                color = Slate800
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Interactive visualization for CPU Order Scheduling (RR Q=2), 4GB Memory Paging & MMU, and Delivery Route Optimization (FCFS, SSTF, SCAN).",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ConceptPill(
                    title = "1. Kitchen CPU",
                    desc = "RR (Q=2) P1–P5",
                    accentColor = OrangeAccent,
                    borderColor = OrangeBorderLight,
                    onClick = { onExploreConcept(DashboardTab.ROUND_ROBIN) },
                    modifier = Modifier.weight(1f)
                )
                ConceptPill(
                    title = "2. RAM Paging",
                    desc = "4GB/4KB & MMU",
                    accentColor = BlueMemory,
                    borderColor = BlueMemoryBorder,
                    onClick = { onExploreConcept(DashboardTab.MEMORY_PAGING) },
                    modifier = Modifier.weight(1f)
                )
                ConceptPill(
                    title = "3. Route Head",
                    desc = "SSTF vs SCAN",
                    accentColor = PurpleRoute,
                    borderColor = PurpleRouteBorder,
                    onClick = { onExploreConcept(DashboardTab.DISK_SCHEDULING) },
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun ConceptPill(
    title: String,
    desc: String,
    accentColor: Color,
    borderColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(1.dp, borderColor),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.ExtraBold,
                color = accentColor
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = desc,
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 10.sp),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

