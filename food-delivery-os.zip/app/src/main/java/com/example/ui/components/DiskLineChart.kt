package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.TwoWheeler
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DividerDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DiskAlgorithm
import com.example.model.DiskSimulationResult
import com.example.model.ScanDirection
import com.example.ui.theme.ChartGridColor
import com.example.ui.theme.ChartLineColor
import com.example.ui.theme.CyanSecondary
import com.example.ui.theme.EmeraldTertiary
import com.example.ui.theme.HitGreen
import com.example.ui.theme.OrangePrimary
import com.example.ui.theme.PurpleBorderLight
import com.example.ui.theme.PurpleContainerLight
import com.example.ui.theme.PurpleDisk
import com.example.ui.theme.PurpleDiskDark
import com.example.ui.theme.Slate100
import com.example.ui.theme.Slate500
import com.example.ui.theme.Slate800

@Composable
fun DiskLineChartSection(
    selectedAlgo: DiskAlgorithm,
    currentResult: DiskSimulationResult,
    fcfsResult: DiskSimulationResult,
    sstfResult: DiskSimulationResult,
    scanResult: DiskSimulationResult,
    lookResult: DiskSimulationResult,
    currentStepIndex: Int,
    isPlaying: Boolean,
    scanDirection: ScanDirection,
    onSelectAlgo: (DiskAlgorithm) -> Unit,
    onStepChange: (Int) -> Unit,
    onTogglePlay: () -> Unit,
    onDirectionChange: (ScanDirection) -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("disk_scheduling_card"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(24.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, PurpleBorderLight),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(PurpleDisk)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "Delivery Courier Route (Disk Scheduling)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.ExtraBold,
                            color = Slate800
                        )
                        Text(
                            text = "Cylinder Range: 0–100 | Initial Head: 40 | Queue: [55, 18, 90, 66, 32, 75]",
                            style = MaterialTheme.typography.bodySmall,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = PurpleDisk
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Algorithm Filter Chips
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                DiskAlgorithm.values().forEach { algo ->
                    FilterChip(
                        selected = selectedAlgo == algo,
                        onClick = { onSelectAlgo(algo) },
                        shape = RoundedCornerShape(16.dp),
                        label = {
                            Text(
                                text = algo.name,
                                fontWeight = if (selectedAlgo == algo) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = PurpleDisk,
                            selectedLabelColor = Color.White
                        ),
                        modifier = Modifier.testTag("chip_disk_${algo.name.lowercase()}")
                    )
                }
            }

            // SCAN direction toggle if SCAN or LOOK is selected
            if (selectedAlgo == DiskAlgorithm.SCAN || selectedAlgo == DiskAlgorithm.LOOK) {
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Sweep Direction:",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = Slate500
                    )
                    FilterChip(
                        selected = scanDirection == ScanDirection.TOWARDS_HIGH,
                        onClick = { onDirectionChange(ScanDirection.TOWARDS_HIGH) },
                        shape = RoundedCornerShape(14.dp),
                        label = { Text("High (→ 100)") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = PurpleDisk,
                            selectedLabelColor = Color.White
                        )
                    )
                    FilterChip(
                        selected = scanDirection == ScanDirection.TOWARDS_LOW,
                        onClick = { onDirectionChange(ScanDirection.TOWARDS_LOW) },
                        shape = RoundedCornerShape(14.dp),
                        label = { Text("Low (← 0)") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = PurpleDisk,
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Scorecard Comparison Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AlgoMetricBadge(
                    algoName = "FCFS",
                    seek = "${fcfsResult.totalSeekDistance} cyl",
                    isSelected = selectedAlgo == DiskAlgorithm.FCFS,
                    isWinner = false,
                    modifier = Modifier.weight(1f)
                )
                AlgoMetricBadge(
                    algoName = "SSTF",
                    seek = "${sstfResult.totalSeekDistance} cyl",
                    isSelected = selectedAlgo == DiskAlgorithm.SSTF,
                    isWinner = true,
                    modifier = Modifier.weight(1f)
                )
                AlgoMetricBadge(
                    algoName = "SCAN",
                    seek = "${scanResult.totalSeekDistance} cyl",
                    isSelected = selectedAlgo == DiskAlgorithm.SCAN,
                    isWinner = false,
                    modifier = Modifier.weight(1f)
                )
                AlgoMetricBadge(
                    algoName = "LOOK",
                    seek = "${lookResult.totalSeekDistance} cyl",
                    isSelected = selectedAlgo == DiskAlgorithm.LOOK,
                    isWinner = false,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Interactive Line Chart Canvas
            Text(
                text = "Head Movement Trajectory Chart (Y: Cylinder 0-100, X: Step Sequence)",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = Slate800
            )

            Spacer(modifier = Modifier.height(8.dp))

            val maxSteps = currentResult.fullSequence.size - 1
            val effectiveStep = currentStepIndex.coerceIn(0, maxOf(0, maxSteps))
            val currentCylinder = currentResult.fullSequence.getOrNull(effectiveStep) ?: currentResult.initialHead

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(230.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(PurpleContainerLight.copy(alpha = 0.45f))
                    .border(1.dp, PurpleBorderLight, RoundedCornerShape(16.dp))
                    .padding(horizontal = 16.dp, vertical = 14.dp)
            ) {
                DiskHeadCanvas(
                    sequence = currentResult.fullSequence,
                    activeStep = effectiveStep,
                    minCyl = 0,
                    maxCyl = 100,
                    modifier = Modifier.matchParentSize()
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Playback Controls
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = { if (currentStepIndex > 0) onStepChange(currentStepIndex - 1) },
                        modifier = Modifier.size(36.dp).testTag("disk_step_back")
                    ) {
                        Icon(Icons.Default.FastRewind, contentDescription = "Step Back", tint = PurpleDisk)
                    }

                    IconButton(
                        onClick = onTogglePlay,
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(PurpleDisk)
                            .testTag("disk_play_pause")
                    ) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = if (isPlaying) "Pause" else "Play",
                            tint = Color.White
                        )
                    }

                    IconButton(
                        onClick = { if (currentStepIndex < maxSteps) onStepChange(currentStepIndex + 1) },
                        modifier = Modifier.size(36.dp).testTag("disk_step_forward")
                    ) {
                        Icon(Icons.Default.FastForward, contentDescription = "Step Next", tint = PurpleDisk)
                    }
                }

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = PurpleContainerLight,
                    border = androidx.compose.foundation.BorderStroke(1.dp, PurpleBorderLight)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Default.TwoWheeler,
                            contentDescription = null,
                            tint = PurpleDiskDark,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Courier at Cyl #$currentCylinder (Hop $effectiveStep/$maxSteps)",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = PurpleDiskDark
                        )
                    }
                }
            }

            Slider(
                value = effectiveStep.toFloat(),
                onValueChange = { onStepChange(it.toInt()) },
                valueRange = 0f..maxOf(0, maxSteps).toFloat(),
                steps = if (maxSteps > 1) maxSteps - 1 else 0,
                colors = SliderDefaults.colors(
                    thumbColor = PurpleDisk,
                    activeTrackColor = PurpleDisk,
                    inactiveTrackColor = PurpleBorderLight
                ),
                modifier = Modifier.fillMaxWidth().testTag("disk_slider")
            )

            // Step Log List
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Sequential Delivery Seek Hops:",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = Slate800
            )

            Spacer(modifier = Modifier.height(6.dp))

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(PurpleContainerLight.copy(alpha = 0.35f))
                    .border(1.dp, PurpleBorderLight, RoundedCornerShape(14.dp))
                    .padding(10.dp)
            ) {
                currentResult.hops.forEachIndexed { idx, hop ->
                    val isPast = idx < effectiveStep
                    val isCurrent = idx == effectiveStep - 1
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Hop #${hop.stepIndex}: ",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = if (isCurrent) PurpleDisk else Slate500
                            )
                            Text(
                                text = "${hop.fromCylinder} → ${hop.toCylinder}",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                                color = Slate800
                            )
                        }
                        Text(
                            text = "+${hop.seekDistance} cyl",
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = if (isCurrent) PurpleDisk else Slate500
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DiskHeadCanvas(
    sequence: List<Int>,
    activeStep: Int,
    minCyl: Int,
    maxCyl: Int,
    modifier: Modifier = Modifier
) {
    val primaryColor = PurpleDisk
    val secondaryColor = PurpleDiskDark
    val onSurfaceColor = Slate800
    val gridLineColor = PurpleBorderLight

    Canvas(modifier = modifier) {
        val width = size.width
        val height = size.height
        val totalSteps = maxOf(1, sequence.size - 1)

        // Draw horizontal grid lines for Cylinder 0, 25, 50, 75, 100
        val gridCylinders = listOf(0, 25, 50, 75, 100)
        gridCylinders.forEach { cyl ->
            val y = height - (cyl.toFloat() / (maxCyl - minCyl)) * height
            drawLine(
                color = gridLineColor,
                start = Offset(0f, y),
                end = Offset(width, y),
                strokeWidth = 1f,
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f), 0f)
            )
            drawContext.canvas.nativeCanvas.drawText(
                "$cyl",
                12f,
                y - 4f,
                android.graphics.Paint().apply {
                    color = onSurfaceColor.copy(alpha = 0.45f).toArgb()
                    textSize = 24f
                    isAntiAlias = true
                }
            )
        }

        // Draw trajectory path
        val path = Path()
        val points = mutableListOf<Offset>()

        sequence.forEachIndexed { i, cyl ->
            val x = (i.toFloat() / totalSteps) * (width - 40f) + 30f
            val y = height - ((cyl - minCyl).toFloat() / (maxCyl - minCyl)) * (height - 30f) - 15f
            points.add(Offset(x, y))
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }

        // Draw full connecting dashed background path
        drawPath(
            path = path,
            color = primaryColor.copy(alpha = 0.25f),
            style = Stroke(width = 3.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 6f), 0f))
        )

        // Draw executed solid path up to activeStep
        val activePath = Path()
        for (i in 0..activeStep.coerceIn(0, points.size - 1)) {
            val pt = points[i]
            if (i == 0) activePath.moveTo(pt.x, pt.y) else activePath.lineTo(pt.x, pt.y)
        }
        drawPath(
            path = activePath,
            brush = Brush.horizontalGradient(listOf(primaryColor, secondaryColor)),
            style = Stroke(width = 4.dp.toPx())
        )

        // Draw points and labels
        points.forEachIndexed { i, pt ->
            val isReached = i <= activeStep
            val isCurrent = i == activeStep
            val cyl = sequence[i]

            // Outer node
            drawCircle(
                color = if (isCurrent) HitGreen else if (isReached) primaryColor else Color.Gray.copy(alpha = 0.4f),
                radius = if (isCurrent) 8.dp.toPx() else 5.dp.toPx(),
                center = pt
            )
            // Inner core
            drawCircle(
                color = Color.White,
                radius = if (isCurrent) 4.dp.toPx() else 2.5.dp.toPx(),
                center = pt
            )

            // Text Label
            drawContext.canvas.nativeCanvas.drawText(
                "$cyl",
                pt.x,
                pt.y - 12f,
                android.graphics.Paint().apply {
                    color = (if (isCurrent) primaryColor else onSurfaceColor).toArgb()
                    textSize = if (isCurrent) 28f else 22f
                    isFakeBoldText = isCurrent
                    textAlign = android.graphics.Paint.Align.CENTER
                    isAntiAlias = true
                }
            )
        }
    }
}

@Composable
private fun AlgoMetricBadge(
    algoName: String,
    seek: String,
    isSelected: Boolean,
    isWinner: Boolean,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        color = if (isSelected) PurpleDisk else PurpleContainerLight,
        border = if (isWinner && !isSelected) androidx.compose.foundation.BorderStroke(1.5.dp, HitGreen) else androidx.compose.foundation.BorderStroke(1.dp, PurpleBorderLight)
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = algoName,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = if (isSelected) Color.White else Slate800
                )
                if (isWinner) {
                    Text(
                        text = "★",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isSelected) Color.White else HitGreen,
                        modifier = Modifier.padding(start = 2.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = seek,
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.ExtraBold,
                color = if (isSelected) Color.White else PurpleDisk
            )
        }
    }
}

